package egovframework.example.util;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.StylesTable;
import org.springframework.stereotype.Component;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

import egovframework.example.sample.service.SampleVO;

@Component
public class ExcelParserUtil {
	// 파싱된 데이터를 VO로 담아서 리턴하는 메서드
    public List<SampleVO> parseExcel(InputStream inputStream) throws Exception {
        List<SampleVO> dataList = new ArrayList<>();

        try (OPCPackage opcPackage = OPCPackage.open(inputStream)) {
            XSSFReader xssfReader = new XSSFReader(opcPackage);
            StylesTable stylesTable = xssfReader.getStylesTable();
            XSSFReader.SheetIterator sheetIterator = (XSSFReader.SheetIterator) xssfReader.getSheetsData();

            while (sheetIterator.hasNext()) {
                try (InputStream sheetInputStream = sheetIterator.next()) {
                    processSheet(stylesTable, sheetInputStream, dataList);
                }
            }
        }

        return dataList;
    }

    // 파싱된 데이터를 배치로 DB에 저장하는 메서드
//    public void parseAndBatchInsert(InputStream inputStream, MyDatabaseService dbService, int batchSize) throws Exception {
//        List<SampleVO> batchList = new ArrayList<>();
//
//        try (OPCPackage opcPackage = OPCPackage.open(inputStream)) {
//            XSSFReader xssfReader = new XSSFReader(opcPackage);
//            StylesTable stylesTable = xssfReader.getStylesTable();
//            XSSFReader.SheetIterator sheetIterator = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
//
//            while (sheetIterator.hasNext()) {
//                try (InputStream sheetInputStream = sheetIterator.next()) {
//                    processSheetWithBatch(stylesTable, sheetInputStream, batchList, dbService, batchSize);
//                }
//            }
//
//            // 남은 데이터 처리
//            if (!batchList.isEmpty()) {
//                dbService.batchInsert(batchList);
//            }
//        }
//    }

    private void processSheet(StylesTable stylesTable, InputStream sheetInputStream, List<SampleVO> dataList) throws Exception {
        DataFormatter dataFormatter = new DataFormatter();
        InputSource inputSource = new InputSource(sheetInputStream);
        XMLReader xmlReader = XMLReaderFactory.createXMLReader();

        XSSFSheetXMLHandler.SheetContentsHandler sheetContentsHandler = new CustomSheetContentsHandler(dataList);
        XSSFSheetXMLHandler sheetXMLHandler = new XSSFSheetXMLHandler(stylesTable, null, sheetContentsHandler, dataFormatter, false);
        xmlReader.setContentHandler(sheetXMLHandler);
        xmlReader.parse(inputSource);
    }

//    private void processSheetWithBatch(StylesTable stylesTable, InputStream sheetInputStream, List<SampleVO> batchList, MyDatabaseService dbService, int batchSize) throws Exception {
//        DataFormatter dataFormatter = new DataFormatter();
//        InputSource inputSource = new InputSource(sheetInputStream);
//        XMLReader xmlReader = XMLReaderFactory.createXMLReader();
//
//        XSSFSheetXMLHandler.SheetContentsHandler sheetContentsHandler = new CustomSheetContentsHandlerWithBatch(batchList, dbService, batchSize);
//        XSSFSheetXMLHandler sheetXMLHandler = new XSSFSheetXMLHandler(stylesTable, null, sheetContentsHandler, dataFormatter, false);
//        xmlReader.setContentHandler(sheetXMLHandler);
//        xmlReader.parse(inputSource);
//    }
}
