package egovframework.example.util;

import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.usermodel.XSSFComment;

import egovframework.example.sample.service.SampleVO;

import java.util.List;

public class CustomSheetContentsHandler implements XSSFSheetXMLHandler.SheetContentsHandler {
    
	private final List<SampleVO> dataList;
    private SampleVO currentData;

    public CustomSheetContentsHandler(List<SampleVO> dataList) {
        this.dataList = dataList;
    }

    @Override
    public void startRow(int rowNum) {
        if (rowNum == 0) {
            // 헤더 행은 무시 (필요하면 수정)
            return;
        }
        currentData = new SampleVO();
    }

    @Override
    public void endRow(int rowNum) {
        if (rowNum != 0 && currentData != null) {
            dataList.add(currentData);
        }
    }

    @Override
    public void cell(String cellReference, String formattedValue, XSSFComment comment) {
        if (currentData != null) {
            switch (cellReference.substring(0, 1)) {
                case "A":
                    currentData.setId(formattedValue);
                    break;
                case "B":
                    currentData.setName(formattedValue);
                    break;
                case "C":
                    currentData.setDescription(formattedValue);
                    break;
                // 필요한 필드를 추가
            }
        }
    }

    @Override
    public void headerFooter(String text, boolean isHeader, String tagName) {
        // 필요 시 구현
    }
}
