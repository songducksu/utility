package egovframework.common.excel;

/**
 * @Class : ExcelMapping.java
 * @Description : 엑셀관련 Value Object와의 맵핑을 위한 인터페이스 
 * @author : 
 * @Modification : 
 */
@Deprecated
public interface ExcelMapping {

	/**
	 * @method mappingColumn
	 * @description 엑셀을 읽고 난 리턴값을 VO객체와 맵핑한다.
	 * @param data
	 * @throws Exception
	 */
	public void mappingColumn(String[] data) throws Exception;
}
