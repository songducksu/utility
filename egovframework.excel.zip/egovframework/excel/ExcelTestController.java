package egovframework.dims.systemMgt.test.web;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.com.cmm.util.EgovDoubleSubmitHelper;
import egovframework.com.cmm.util.EgovUserDetailsHelper;
import egovframework.common.excel.config.ExcelConfig;
import egovframework.common.util.EgovDateUtil;
import egovframework.common.web.DefaultController;
import egovframework.dims.systemMgt.test.service.TestService;
import egovframework.dims.systemMgt.test.vo.TestVO;
import egovframework.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

@Controller
public class ExcelTestController extends DefaultController {
	
    @Resource(name = "TestService")
    private TestService testService;
    
	@RequestMapping(value = "/test/excelDownload.do")
	public String excelDownload(@ModelAttribute("testVO") TestVO testVO,
    		ModelMap model) throws Exception {
		
		PaginationInfo paginationInfo = new PaginationInfo();
		testVO.setSerchWay("ALL");
		
		List<List<List<String>>> excelList = new ArrayList<List<List<String>>>();
		List<String> sheetName = Arrays.asList(
				                                 "엑셀시트1"
				                               , "엑셀시트2"
				                              );
		
		List<List<String>> headName = Arrays.asList(
													  Arrays.asList("번호", "컬럼1", "컬럼2", "컬럼3", "컬럼4", "컬럼5")
													, Arrays.asList("번호", "컬럼1", "컬럼2", "컬럼3", "컬럼4", "컬럼5")
				                                   );
		
		String fileName = java.net.URLEncoder.encode("한글파일명"+ "_" + EgovDateUtil.getDateTime(),"UTF-8");
		
		List<List<String>> fldResultList  = new ArrayList<List<String>>();
		List<List<String>> codeResultList = new ArrayList<List<String>>();
		List<TestVO> msgList  = new ArrayList<TestVO>();
		List<TestVO> fldList  = new ArrayList<TestVO>();
		List<TestVO> codeList = new ArrayList<TestVO>();
		
		msgList = testService.list(paginationInfo, testVO).getContet();
		
		int i = 1;
	
		for(TestVO msgVO : msgList){

			msgVO.setSerchWay(testVO.getSerchWay());
			fldList = testService.fldList(msgVO);
			
	    	for(TestVO fldVO : fldList){
	    
	    		fldResultList.add(
								    Arrays.asList(String.valueOf(i++)
								  ,	msgVO.getColumn1Nm()
								  ,	msgVO.getColumn2Nm()
								  ,	msgVO.getColumn3Nm()
								  ,	msgVO.getColumn4Nm()
								  ,	msgVO.getColumn5Nm()
			    ));
	    		
	    		if(fldVO.getCdTestCnt() > 0){
	    			
		    		codeList = testService.codeList(fldVO);
		    		
		    		for(TestVO codeVO : codeList){
		    			
		    			codeResultList.add(
										    Arrays.asList(String.valueOf(i)
									      ,	msgVO.getMsgId()	
									      ,	msgVO.getMsgNm()	
										  , fldVO.getSetId()
										  , fldVO.getSetNm()										    		
										  , String.valueOf(codeVO.getSeqc())
							              , codeVO.getCvsnBfCdvalnm()
							              , codeVO.getCvsnAftCdvalnm()
		               ));
		    		}
	    		}
	    	}
		}
		
		if(fldList.size() < 1) fldResultList.add(Arrays.asList("", "", "", "", "", "", "", "", "", "", "", ""));
		if(codeResultList.size() < 1) codeResultList.add(Arrays.asList("", "", "", "", "", "", "", ""));
		
		excelList.add(fldResultList);
		excelList.add(codeResultList);
		
		model.addAttribute(ExcelConfig.FILE_NAME, fileName);
		model.addAttribute(ExcelConfig.SHEET, sheetName);
		model.addAttribute(ExcelConfig.HEAD, headName);
		model.addAttribute(ExcelConfig.BODY, excelList);

		return "excelView";
		
	}
}