package egovframework.common.excel.component;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import egovframework.common.util.ExcelUtil;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
 
/* 
 * Copyright ⓒ 2018. Ministry of National Defense All Right Reserved
 * Licensed under the Apache License. Version 2.0(the “License”);
 * you may not use this file except in compliance with the License.
 * 
 * 파일 제목 : ExcelView.java
 * 설     명 : Excel 다운로드 공통 View Resolver 클래스
 * 개 발 자 : song
 * 개 발 일 : 2019-09-19
 * 버     전 : 1.0
 * 수정 이력 :
 * 수정 1: 성능문제로 ExcelDownView.java로 변경  - deprecated 2018-10-22
 */
@Deprecated
public class ExcelView extends AbstractExcelPOIView {
 
    @Override
    protected void buildExcelDocument(Map<String, Object> model, 
    		Workbook workbook, 
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception {
    	new ExcelUtil(workbook, model, response).createExcel();
    }

	@Override
	protected Workbook createWorkbook() {
		return new SXSSFWorkbook(200);
	}

}
