package egovframework.common.excel.component;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import egovframework.common.excel.config.ExcelConfig;
 
public class ExcelDownView extends AbstractExcelPOIView {
 
	private static final Logger LOGGER = LoggerFactory.getLogger(ExcelDownView.class);
	
    @SuppressWarnings("unchecked")
	@Override
    protected void buildExcelDocument(Map<String, Object> model, 
    		Workbook workbook, 
    		HttpServletRequest request, 
    		HttpServletResponse response) throws Exception {
    	
    	long startDt = System.currentTimeMillis();
    	LOGGER.info("ExcelDownView 시작 : " + startDt);
    	
    	String fileName = (String) model.get(ExcelConfig.FILE_NAME);
    	List<String> sheetName = (List<String>) model.get(ExcelConfig.SHEET);
    	List<List<String>> headName = (List<List<String>>) model.get(ExcelConfig.HEAD);
    	List<List<List<String>>> excelList = (List<List<List<String>>>) model.get(ExcelConfig.BODY);
    	
    	CellStyle hcs = getHeaderCellStyle(workbook);
    	CellStyle ccs = getContentCellStyle(workbook);
    	
    	// sheet
    	for(int i=0; i<sheetName.size(); i++){

    		Sheet sheet = workbook.createSheet(sheetName.get(i));
    		Row row = null;

    		// head
    		row = sheet.createRow(0);
    		for(int j=0; j<headName.get(i).size(); j++){
    			Cell cell = row.createCell(j);
    			cell.setCellStyle(hcs);
    			cell.setCellValue(headName.get(i).get(j));
    		}
    		
    		// row
    		for(int j=0; j<excelList.get(i).size(); j++){
    			row = sheet.createRow(j+1);
    			int excelSize = excelList.get(i).get(j).size();
    			for(int k=0; k<excelSize; k++){
    				Cell cell = row.createCell(k);
    				cell.setCellStyle(ccs);
    				cell.setCellValue(excelList.get(i).get(j).get(k));
    			}
    		}
    		
    		// cell width
    		if(sheet.getRow(1) != null){
	    		for(int j=0; j<sheet.getRow(1).getPhysicalNumberOfCells(); j++){
	    			sheet.autoSizeColumn(j);
	    			int width = sheet.getColumnWidth(j);
	    			int minWidth = headName.get(i).get(j).getBytes().length * 450;
	    			int maxWidth = 18000;
	    			if(minWidth > width){
	    				sheet.setColumnWidth(j, minWidth);
	    			}else if(width > maxWidth){
	    				sheet.setColumnWidth(j, maxWidth);
	    			}else{
	    				sheet.setColumnWidth(j, width + 2000);
	    			}
	    		}
    		}
    		
    	}
    	
    	response.setHeader("Content-Disposition", "attachment; filename=\"" + setFileExtension(workbook, fileName) + "\"");
    	
    	long endDt = System.currentTimeMillis();
		LOGGER.info("ExcelDownView 끝 : " + endDt);
		long finalDt = endDt - startDt;
		LOGGER.info("ExcelDownView 시간 : " + finalDt/1000 + "sec");
    	
    }

	@Override
	protected Workbook createWorkbook() {
		return new XSSFWorkbook();
	}
	
	public CellStyle getTitleCellStyle(Workbook workbook){
		Font tf = workbook.createFont();
		tf.setFontHeightInPoints((short)14);
		tf.setBoldweight(Font.BOLDWEIGHT_NORMAL);
		
		CellStyle tcs = workbook.createCellStyle();
		tcs.setAlignment(CellStyle.ALIGN_CENTER);
		tcs.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
		tcs.setFont(tf);
		
		return tcs;
	}
	
	public CellStyle getHeaderCellStyle(Workbook workbook){
		CellStyle hcs = workbook.createCellStyle();
		hcs.setAlignment(CellStyle.ALIGN_CENTER);
		hcs.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
		hcs.setFillPattern(CellStyle.SOLID_FOREGROUND);
		hcs.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		hcs.setBorderTop(CellStyle.BORDER_THIN);
		hcs.setBorderBottom(CellStyle.BORDER_THIN);
		hcs.setBorderLeft(CellStyle.BORDER_THIN);
		hcs.setBorderRight(CellStyle.BORDER_THIN);
		
		return hcs;
	}

	public CellStyle getContentCellStyle(Workbook workbook){
		CellStyle ccs = workbook.createCellStyle();
		ccs.setBottomBorderColor(IndexedColors.BLACK.getIndex());
		ccs.setBorderTop(CellStyle.BORDER_THIN);
		ccs.setBorderBottom(CellStyle.BORDER_THIN);
		ccs.setBorderLeft(CellStyle.BORDER_THIN);
		ccs.setBorderRight(CellStyle.BORDER_THIN);
		
		return ccs;
	}
	
	private String setFileExtension(Workbook workbook, String fileName) {
		if (workbook instanceof XSSFWorkbook) {
			fileName += ".xlsx";
		}
		if (workbook instanceof SXSSFWorkbook) {
			fileName += ".xlsx";
		}
		if (workbook instanceof HSSFWorkbook) {
			fileName += ".xls";
		}

		return fileName;
	}
	
}
