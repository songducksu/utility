package egovframework.common.excel.config;

/* 
 * Copyright ⓒ 2018. Ministry of National Defense All Right Reserved
 * Licensed under the Apache License. Version 2.0(the “License”);
 * you may not use this file except in compliance with the License.
 * 
 * 파일 제목 : ExcelConfig.java
 * 설     명 : Excel 관련 상수 정의 클래스
 * 개 발 자 : song
 * 개 발 일 : 2019-09-19
 * 버     전 : 1.0
 * 수정 이력 :
 * 수정 1: 
 */
public class ExcelConfig {

    public static final String FILE_NAME = "fileName";
    public static final String SHEET = "sheet";
    public static final String HEAD = "head";
    public static final String BODY = "body";

    public static final String XLS = "xls";
    public static final String XLSX = "xlsx";
}
